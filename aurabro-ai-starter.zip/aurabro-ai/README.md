# AuraBro AI

Eine kleine Web-App für iPhone/Safari und Desktop. Sie kann Text, Chatverlauf und einen Screenshot an einen KI-Dienst senden und drei Antwortvorschläge erstellen.

## Voraussetzungen
- Node.js 18 oder neuer
- Ein eigener OpenAI-API-Schlüssel mit aktivierter API-Abrechnung

## Lokal starten

macOS/Linux:
```bash
export OPENAI_API_KEY="DEIN_API_SCHLUESSEL"
npm start
```

Windows PowerShell:
```powershell
$env:OPENAI_API_KEY="DEIN_API_SCHLUESSEL"
npm start
```

Dann im Browser `http://localhost:3000` öffnen.

Optional kannst du ein anderes unterstütztes Modell über `OPENAI_MODEL` setzen. Standard ist `gpt-4.1-mini`.

## Online stellen
Die App braucht einen Node.js-Host. Lade diesen Projektordner zu einem Hosting-Anbieter hoch, setze dort `OPENAI_API_KEY` als geheime Umgebungsvariable und starte mit `npm start`. Erst danach erhältst du eine öffentliche HTTPS-Adresse, die du in Safari öffnen kannst.

**Wichtig:** Den API-Schlüssel niemals in `public/index.html` eintragen oder öffentlich teilen. API-Nutzung kann Kosten verursachen. Prüfe Limits und Abrechnung beim Anbieter, bevor du die App veröffentlichst.
